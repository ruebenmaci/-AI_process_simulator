import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Pane {
    id: root
    property var flowsheet
    property real mouseSheetX: -1
    property real mouseSheetY: -1
    signal unitDoubleClicked(string unitId)
    signal disconnectCompleted(bool success, string unitId)

    property string connectionMode: "none" // none | feed | distillate | bottoms | disconnect
    property string pendingConnectionUnitId: ""
    property string connectionStatusText: ""

    // ── Placement mode ────────────────────────────────────────────────────
    // Set placementType to "column" or "stream" to enter placement mode.
    // A ghost icon follows the cursor; left-click drops the unit there.
    property string placementType: ""   // "" = inactive
    readonly property bool inPlacementMode: placementType !== ""

    function beginPlacement(unitType) {
        placementType = unitType
        sheet.forceActiveFocus()
    }

    function cancelPlacement() {
        placementType = ""
    }

    property real designDrawingWidth: 1180
    property real designDrawingHeight: 760
    property var unitRelPos: ({})
    property real canvasScale: {
        const sx = drawingBorder.width / Math.max(1, designDrawingWidth)
        const sy = drawingBorder.height / Math.max(1, designDrawingHeight)
        return Math.max(0.5, Math.min(Math.min(sx, sy), 2.0))
    }

    function clamp(v, lo, hi) {
        return Math.max(lo, Math.min(hi, v))
    }

    function usableWidthForItem(item) {
        return Math.max(0, drawingBorder.width - item.width)
    }

    function usableHeightForItem(item) {
        return Math.max(0, drawingBorder.height - item.height)
    }

    function ensureUnitRelPos(unitId, absX, absY, item) {
        if (unitRelPos[unitId] !== undefined)
            return unitRelPos[unitId]

        const w = item ? usableWidthForItem(item) : Math.max(1, drawingBorder.width)
        const h = item ? usableHeightForItem(item) : Math.max(1, drawingBorder.height)
        const rel = {
            x: clamp((absX - drawingBorder.x) / Math.max(1, w), 0, 1),
            y: clamp((absY - drawingBorder.y) / Math.max(1, h), 0, 1)
        }

        const copy = Object.assign({}, unitRelPos)
        copy[unitId] = rel
        unitRelPos = copy
        return rel
    }

    function updateUnitRelPos(unitId, absX, absY, item) {
        const w = item ? usableWidthForItem(item) : Math.max(1, drawingBorder.width)
        const h = item ? usableHeightForItem(item) : Math.max(1, drawingBorder.height)
        const copy = Object.assign({}, unitRelPos)
        copy[unitId] = {
            x: clamp((absX - drawingBorder.x) / Math.max(1, w), 0, 1),
            y: clamp((absY - drawingBorder.y) / Math.max(1, h), 0, 1)
        }
        unitRelPos = copy
    }

    function applyStoredUnitPosition(item, unitId) {
        if (!item)
            return

        const rel = unitRelPos[unitId] !== undefined
            ? unitRelPos[unitId]
            : ensureUnitRelPos(unitId, item.x, item.y, item)

        const nx = drawingBorder.x + rel.x * usableWidthForItem(item)
        const ny = drawingBorder.y + rel.y * usableHeightForItem(item)
        item.applyConstrainedPosition(nx, ny)
    }

    function repositionUnitsFromStoredCoords() {
        if (!unitRepeater || unitRepeater.count <= 0)
            return

        for (let i = 0; i < unitRepeater.count; ++i) {
            const item = unitRepeater.itemAt(i)
            if (!item)
                continue
            applyStoredUnitPosition(item, item.unitId)
        }
    }


    function unitItemById(unitId) {
        if (!unitRepeater || unitRepeater.count <= 0)
            return null
        for (let i = 0; i < unitRepeater.count; ++i) {
            const item = unitRepeater.itemAt(i)
            if (item && item.unitId === unitId)
                return item
        }
        return null
    }

    function itemCenter(unitId) {
        const item = unitItemById(unitId)
        if (!item)
            return null
        return { x: item.x + item.width / 2, y: item.y + item.height / 2, item: item }
    }

    function itemPortPoint(unitId, portName) {
        const c = itemCenter(unitId)
        if (!c)
            return null

        const item = c.item
        const type = root.flowsheet ? root.flowsheet.unitType(unitId) : ""
        const port = (portName || "").toLowerCase()

        if (type === "column") {
            if (port === "feed")
                return { x: item.x + Math.max(6, item.width * 0.12), y: item.y + item.height * 0.50 }
            if (port === "distillate")
                return { x: item.x + item.width * 0.50, y: item.y + Math.max(4, item.height * 0.06) }
            if (port === "bottoms")
                return { x: item.x + item.width * 0.50, y: item.y + item.height * 0.86 }
        }

        return { x: c.x, y: c.y }
    }

    function drawConnectionLine(ctx, x1, y1, x2, y2) {
        const midX = (x1 + x2) / 2
        ctx.beginPath()
        ctx.moveTo(x1, y1)
        ctx.bezierCurveTo(midX, y1, midX, y2, x2, y2)
        ctx.stroke()
    }

    function handleConnectionClick(unitId) {
        if (!root.flowsheet || root.connectionMode === "none")
            return false

        const clickedType = root.flowsheet.unitType(unitId)
        if (clickedType === "")
            return false

        if (root.connectionMode === "disconnect") {
            if (clickedType !== "stream") {
                root.connectionStatusText = "Disconnect mode: click a stream."
                return true
            }
            const ok = root.flowsheet.disconnectMaterialStream(unitId)
            root.connectionStatusText = ok
                ? (unitId + " disconnected.")
                : (unitId + " had no material binding.")
            root.pendingConnectionUnitId = ""
            connectionOverlay.requestPaint()
            if (ok)
                root.disconnectCompleted(true, unitId)
            return true
        }

        if (root.pendingConnectionUnitId === "") {
            root.pendingConnectionUnitId = unitId
            root.connectionStatusText = "Selected " + unitId + ". Click the matching stream/column to complete the connection."
            connectionOverlay.requestPaint()
            return true
        }

        if (root.pendingConnectionUnitId === unitId) {
            root.connectionStatusText = "Selection cleared."
            root.pendingConnectionUnitId = ""
            connectionOverlay.requestPaint()
            return true
        }

        const firstId = root.pendingConnectionUnitId
        const firstType = root.flowsheet.unitType(firstId)
        let streamId = ""
        let columnId = ""

        if (firstType === "stream" && clickedType === "column") {
            streamId = firstId
            columnId = unitId
        } else if (firstType === "column" && clickedType === "stream") {
            streamId = unitId
            columnId = firstId
        } else {
            root.connectionStatusText = "Connect one stream and one column."
            return true
        }

        let ok = false
        if (root.connectionMode === "feed")
            ok = root.flowsheet.bindColumnFeedStream(columnId, streamId)
        else if (root.connectionMode === "distillate")
            ok = root.flowsheet.bindColumnProductStream(columnId, "distillate", streamId)
        else if (root.connectionMode === "bottoms")
            ok = root.flowsheet.bindColumnProductStream(columnId, "bottoms", streamId)

        root.connectionStatusText = ok
            ? (streamId + " bound to " + columnId + " as " + root.connectionMode + ".")
            : "Binding failed."
        root.pendingConnectionUnitId = ""
        connectionOverlay.requestPaint()
        return true
    }

    function resetConnectionSelection() {
        root.pendingConnectionUnitId = ""
        root.connectionStatusText = ""
        connectionOverlay.requestPaint()
    }

    function hideContextMenu() {
        contextMenuRect.visible = false
        root.contextMenuUnitId = ""
        root.contextMenuUnitType = ""
        root.contextMenuConnected = false
    }

    function tryDeleteUnit(unitId) {
        if (!root.flowsheet || unitId === "") return
        root.flowsheet.selectUnit(unitId)
        root.flowsheet.deleteSelectedUnitAndConnections()
        root.hideContextMenu()
        connectionOverlay.requestPaint()
    }

    function isStreamConnected(unitId) {
        if (!root.flowsheet) return false
        const connections = root.flowsheet.materialConnections
        for (let i = 0; i < connections.length; ++i) {
            if (connections[i].streamUnitId === unitId)
                return true
        }
        return false
    }

    function showContextMenu(unitId, sheetX, sheetY) {
        if (!root.flowsheet) return
        const unitType = root.flowsheet.unitType(unitId)
        if (unitType === "") return

        root.flowsheet.selectUnit(unitId)
        root.contextMenuUnitId = unitId
        root.contextMenuUnitType = unitType
        root.contextMenuConnected = (unitType === "stream") && root.isStreamConnected(unitId)
        const menuH = root.contextMenuConnected ? 72 : 38
        contextMenuRect.x = Math.max(4, Math.min(sheetX, sheet.width  - 196))
        contextMenuRect.y = Math.max(4, Math.min(sheetY, sheet.height - menuH - 4))
        contextMenuRect.visible = true
    }

    property string contextMenuUnitId: ""
    property string contextMenuUnitType: ""
    property bool   contextMenuConnected: false

    // ── Drag-to-connect snap state ────────────────────────────────────────
    // When a stream is dragged near a column port, we highlight that port
    // and auto-connect on drop.
    property string snapColumnId: ""    // column being snapped to
    property string snapPortName: ""    // "feed" | "distillate" | "bottoms"
    readonly property bool snapActive: snapColumnId !== "" && snapPortName !== ""
    property string draggingUnitId: ""  // unitId of item currently being dragged

    // How close (px) the stream centre must be to a port to snap
    readonly property real snapRadius: 48

    // Port positions on a column item (mirrors itemPortPoint logic)
    function columnPortPoint(colItem, port) {
        if (!colItem) return null
        const iconH = colItem.height - colItem.labelAreaHeight - 4
        if (port === "feed")
            return Qt.point(colItem.x,
                            colItem.y + iconH * 0.50)
        if (port === "distillate")
            return Qt.point(colItem.x + colItem.width * 0.50,
                            colItem.y)
        if (port === "bottoms")
            return Qt.point(colItem.x + colItem.width * 0.50,
                            colItem.y + iconH * 0.90)
        return null
    }

    // Check all columns for snap proximity while a stream is being dragged.
    // streamItem: the UnitNodeItem being dragged
    function updateSnapTarget(streamItem) {
        if (!root.flowsheet || !streamItem) {
            snapColumnId = ""; snapPortName = ""; return
        }

        const sx = streamItem.x + streamItem.width  / 2
        const sy = streamItem.y + streamItem.height / 2

        // Gather existing connections so we don't offer already-bound ports
        const connections = root.flowsheet.materialConnections

        let bestDist = root.snapRadius
        let bestCol  = ""
        let bestPort = ""

        for (let i = 0; i < unitRepeater.count; ++i) {
            const item = unitRepeater.itemAt(i)
            if (!item || item.unitType !== "column") continue

            const colId = item.unitId

            const ports = ["feed", "distillate", "bottoms"]
            for (let p = 0; p < ports.length; ++p) {
                const port = ports[p]
                // Skip ports that are already connected
                let alreadyConnected = false
                for (let c = 0; c < connections.length; ++c) {
                    const conn = connections[c]
                    if (conn.targetUnitId === colId && conn.targetPort === port) {
                        alreadyConnected = true; break
                    }
                    if (conn.sourceUnitId === colId && conn.sourcePort === port) {
                        alreadyConnected = true; break
                    }
                }
                if (alreadyConnected) continue

                const pp = columnPortPoint(item, port)
                if (!pp) continue

                const dist = Math.sqrt((sx - pp.x) * (sx - pp.x) +
                                       (sy - pp.y) * (sy - pp.y))
                if (dist < bestDist) {
                    bestDist = dist
                    bestCol  = colId
                    bestPort = port
                }
            }
        }

        if (bestCol !== snapColumnId || bestPort !== snapPortName) {
            snapColumnId = bestCol
            snapPortName = bestPort
            connectionOverlay.requestPaint()
        }
    }

    function clearSnapTarget() {
        if (snapColumnId !== "" || snapPortName !== "") {
            snapColumnId = ""
            snapPortName = ""
            connectionOverlay.requestPaint()
        }
    }

    // Attempt auto-connect on drop
    function trySnapConnect(streamId) {
        if (!snapActive || !root.flowsheet) return false
        let ok = false
        if (snapPortName === "feed")
            ok = root.flowsheet.bindColumnFeedStream(snapColumnId, streamId)
        else if (snapPortName === "distillate")
            ok = root.flowsheet.bindColumnProductStream(snapColumnId, "distillate", streamId)
        else if (snapPortName === "bottoms")
            ok = root.flowsheet.bindColumnProductStream(snapColumnId, "bottoms", streamId)
        clearSnapTarget()
        if (ok) connectionOverlay.requestPaint()
        return ok
    }

    // Called from delegate onMoved — checks snap at final dropped position
    function onStreamDropped(unitId) {
        if (!root.flowsheet) return
        if (root.flowsheet.unitType(unitId) !== "stream") {
            clearSnapTarget()
            return
        }
        const item = unitItemById(unitId)
        if (item) {
            updateSnapTarget(item)
            if (root.snapActive)
                trySnapConnect(unitId)
        }
        clearSnapTarget()
    }

    padding: 12

    background: Rectangle {
        color: "#d8e0e5"
        border.color: "#b9c5cc"
        radius: 10
    }

    Item {
        anchors.fill: parent

        Rectangle {
            id: sheet
            anchors.fill: parent
            anchors.margins: 6
            color: "white"
            border.color: "#8f989f"
            border.width: 1
            radius: 2

            MouseArea {
                id: mouseTracker
                anchors.fill: parent
                acceptedButtons: root.inPlacementMode ? Qt.LeftButton | Qt.RightButton : Qt.NoButton
                hoverEnabled: true
                z: root.inPlacementMode ? 10 : -1
                cursorShape: root.inPlacementMode ? Qt.CrossCursor : Qt.ArrowCursor

                onPositionChanged: function(mouse) {
                    root.mouseSheetX = mouse.x
                    root.mouseSheetY = mouse.y
                    // Live snap detection while a stream is being dragged
                    if (root.draggingUnitId !== "") {
                        const item = root.unitItemById(root.draggingUnitId)
                        if (item)
                            root.updateSnapTarget(item)
                    }
                }

                onExited: {
                    root.mouseSheetX = -1
                    root.mouseSheetY = -1
                    root.draggingUnitId = ""
                    root.clearSnapTarget()
                }

                onClicked: function(mouse) {
                    if (!root.inPlacementMode) return
                    if (mouse.button === Qt.RightButton) {
                        root.cancelPlacement()
                        return
                    }
                    // Place the unit at the clicked position (clamped to drawing border)
                    const px = Math.max(drawingBorder.x, Math.min(mouse.x, drawingBorder.x + drawingBorder.width  - 10))
                    const py = Math.max(drawingBorder.y, Math.min(mouse.y, drawingBorder.y + drawingBorder.height - 10))
                    if (root.placementType === "column")
                        root.flowsheet.addColumn(px, py)
                    else if (root.placementType === "stream")
                        root.flowsheet.addStream(px, py)
                    root.cancelPlacement()
                }
            }

            Rectangle {
                id: drawingBorder
                x: 10
                y: 10
                width: sheet.width - 20
                height: sheet.height - 20
                color: "transparent"
                border.color: "#7f8890"
                border.width: 1
            }

            Canvas {
                id: connectionOverlay
                anchors.fill: drawingBorder
                z: -1
                enabled: false

                onPaint: {
                    const ctx = getContext("2d")
                    ctx.clearRect(0, 0, width, height)

                    if (!root.flowsheet)
                        return

                    const connections = root.flowsheet.materialConnections
                    ctx.lineWidth = 2
                    ctx.strokeStyle = "#3e78a8"

                    for (let i = 0; i < connections.length; ++i) {
                        const c = connections[i]
                        const streamId = c.streamUnitId || ""
                        const sourceUnitId = c.sourceUnitId || ""
                        const sourcePort = c.sourcePort || ""
                        const targetUnitId = c.targetUnitId || ""
                        const targetPort = c.targetPort || ""

                        let p1 = null
                        let p2 = null
                        if (targetUnitId !== "") {
                            p1 = root.itemPortPoint(streamId, "")
                            p2 = root.itemPortPoint(targetUnitId, targetPort)
                        } else if (sourceUnitId !== "") {
                            p1 = root.itemPortPoint(sourceUnitId, sourcePort)
                            p2 = root.itemPortPoint(streamId, "")
                        }

                        if (!p1 || !p2)
                            continue

                        root.drawConnectionLine(ctx, p1.x - drawingBorder.x, p1.y - drawingBorder.y, p2.x - drawingBorder.x, p2.y - drawingBorder.y)
                    }

                    if (root.pendingConnectionUnitId !== "") {
                        const pending = root.itemPortPoint(root.pendingConnectionUnitId, root.connectionMode) || root.itemPortPoint(root.pendingConnectionUnitId, "")
                        if (pending) {
                            ctx.beginPath()
                            ctx.setLineDash([5, 5])
                            ctx.arc(pending.x - drawingBorder.x, pending.y - drawingBorder.y, 12, 0, Math.PI * 2)
                            ctx.strokeStyle = "#cc7a00"
                            ctx.stroke()
                            ctx.setLineDash([])
                        }
                    }

                    // ── Drag-to-connect snap indicator ────────────────────
                    if (root.snapActive) {
                        const colItem = root.unitItemById(root.snapColumnId)
                        if (colItem) {
                            const pp = root.columnPortPoint(colItem, root.snapPortName)
                            if (pp) {
                                const px = pp.x - drawingBorder.x
                                const py = pp.y - drawingBorder.y

                                // Outer glow ring
                                ctx.beginPath()
                                ctx.arc(px, py, 14, 0, Math.PI * 2)
                                ctx.strokeStyle = "#00c080"
                                ctx.lineWidth = 3
                                ctx.setLineDash([])
                                ctx.stroke()

                                // Filled inner dot
                                ctx.beginPath()
                                ctx.arc(px, py, 6, 0, Math.PI * 2)
                                ctx.fillStyle = "#00c080"
                                ctx.fill()

                                // Port label (Feed / Distillate / Bottoms)
                                const label = root.snapPortName.charAt(0).toUpperCase()
                                              + root.snapPortName.slice(1)
                                ctx.font = "bold 11px sans-serif"
                                ctx.fillStyle = "#00802a"
                                ctx.fillText(label, px + 18, py + 4)
                            }
                        }
                    }
                }
            }

            Connections {
                target: drawingBorder
                function onWidthChanged() { resizeSyncTimer.restart() }
                function onHeightChanged() { resizeSyncTimer.restart() }
            }

            Repeater {
                id: unitRepeater
                model: root.flowsheet ? root.flowsheet.unitModel : null

                delegate: UnitNodeItem {
                    property bool initializedRelPos: false

                    x: model.x
                    y: model.y
                    unitId: model.unitId
                    name: model.name
                    unitType: model.type
                    flowsheet: root.flowsheet
                    dragBounds: sheet
                    dragPaddingLeft: drawingBorder.x
                    dragPaddingTop: drawingBorder.y
                    dragPaddingRight: sheet.width - (drawingBorder.x + drawingBorder.width)
                    dragPaddingBottom: sheet.height - (drawingBorder.y + drawingBorder.height)
                    exclusionRect: Qt.rect(titleBlock.x, titleBlock.y, titleBlock.width, titleBlock.height)
                    exclusionRect2: Qt.rect(mouseDebugBox.x, mouseDebugBox.y, mouseDebugBox.width, mouseDebugBox.height)
                    selected: root.flowsheet ? root.flowsheet.selectedUnitId === model.unitId : false
                    pendingConnectionSelection: root.pendingConnectionUnitId === model.unitId
                    canvasScale: root.canvasScale

                    Component.onCompleted: {
                        root.ensureUnitRelPos(unitId, model.x, model.y, this)
                        Qt.callLater(function() { root.applyStoredUnitPosition(this, unitId) }.bind(this))
                    }

                    onWidthChanged: Qt.callLater(root.repositionUnitsFromStoredCoords)
                    onHeightChanged: Qt.callLater(root.repositionUnitsFromStoredCoords)

                    onClicked: function(unitId) {
                        root.hideContextMenu()
                        if (root.flowsheet)
                            root.flowsheet.selectUnit(unitId)
                        // Track which stream is being dragged for live snap detection
                        if (root.flowsheet && root.flowsheet.unitType(unitId) === "stream")
                            root.draggingUnitId = unitId
                        if (root.handleConnectionClick(unitId))
                            return
                    }

                    onRightClicked: function(unitId, mouseX, mouseY) {
                        root.showContextMenu(unitId, mouseX, mouseY)
                    }

                    onDoubleClicked: function(unitId) {
                        if (root.flowsheet)
                            root.flowsheet.selectUnit(unitId)
                        root.unitDoubleClicked(unitId)
                    }

                    onMoved: function(unitId, nodeX, nodeY) {
                        root.updateUnitRelPos(unitId, nodeX, nodeY, this)
                        if (root.flowsheet)
                            root.flowsheet.moveUnit(unitId, nodeX, nodeY)
                        // Snap-connect: if a stream was dropped near a column port, auto-connect
                        root.onStreamDropped(unitId)
                        root.draggingUnitId = ""
                        connectionOverlay.requestPaint()
                    }
                }
            }

            Timer {
                id: resizeSyncTimer
                interval: 0
                repeat: false
                onTriggered: {
                    root.repositionUnitsFromStoredCoords()
                    connectionOverlay.requestPaint()
                }
            }

            // Polls item position during drag to update live snap indicator
            Timer {
                id: snapPollTimer
                interval: 33   // ~30 fps
                repeat: true
                running: root.draggingUnitId !== ""
                onTriggered: {
                    if (root.draggingUnitId === "") {
                        stop()
                        return
                    }
                    const item = root.unitItemById(root.draggingUnitId)
                    if (item)
                        root.updateSnapTarget(item)
                    else
                        root.clearSnapTarget()
                }
            }

            Connections {
                target: root.flowsheet
                function onMaterialConnectionsChanged() { connectionOverlay.requestPaint() }
                function onSelectedUnitChanged() { connectionOverlay.requestPaint() }
            }

            Rectangle {
                id: mouseDebugBox
                anchors.left: drawingBorder.left
                anchors.bottom: drawingBorder.bottom
                anchors.margins: 6
                width: 150
                height: 30
                color: "white"
                border.color: "#7f8890"
                border.width: 1

                Label {
                    anchors.centerIn: parent
                    font.pixelSize: 12
                    color: "#31404a"
                    text: root.mouseSheetX >= 0
                          ? "Mouse: " + Math.round(root.mouseSheetX) + ", " + Math.round(root.mouseSheetY)
                          : "Mouse: -, -"
                }
            }

            Rectangle {
                id: titleBlock
                anchors.right: drawingBorder.right
                anchors.bottom: drawingBorder.bottom
                width: 220
                height: 82
                color: "white"
                border.color: "#7f8890"
                border.width: 1

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 6
                    spacing: 2

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Label {
                            text: "Title"
                            font.bold: true
                            color: "#2f3b44"
                            Layout.preferredWidth: 56
                        }
                        Rectangle { Layout.fillWidth: true; height: 1; color: "transparent" }
                    }
                    Rectangle { Layout.fillWidth: true; height: 1; color: "#b7bfc5" }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Label { text: "Date"; font.bold: true; color: "#51616c"; Layout.preferredWidth: 56 }
                        Label { text: Qt.formatDate(new Date(), "yyyy-MM-dd"); color: "#31404a"; Layout.fillWidth: true; horizontalAlignment: Text.AlignRight }
                    }
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Label { text: "Rev"; font.bold: true; color: "#51616c"; Layout.preferredWidth: 56 }
                        Label { text: "0"; color: "#31404a"; Layout.fillWidth: true; horizontalAlignment: Text.AlignRight }
                    }
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Label { text: "Drawn By"; font.bold: true; color: "#51616c"; Layout.preferredWidth: 56 }
                        Label { text: ""; color: "#31404a"; Layout.fillWidth: true; horizontalAlignment: Text.AlignRight }
                    }
                }
            }

            // ── Placement ghost icon ──────────────────────────────────────
            // Follows the mouse cursor when placement mode is active.
            // Shows a semi-transparent preview of the icon to be placed.
            Item {
                id: placementGhost
                visible: root.inPlacementMode && root.mouseSheetX >= 0
                z: 20
                width:  root.placementType === "column" ? 100 : 50
                height: root.placementType === "column" ? 100 : 50
                x: root.mouseSheetX - width  / 2
                y: root.mouseSheetY - height / 2

                opacity: 0.72

                Rectangle {
                    anchors.fill: parent
                    radius: 4
                    color:       "transparent"
                    border.color: "#2f6fa3"
                    border.width: 2
                }

                Image {
                    anchors.fill: parent
                    anchors.margins: 3
                    source: root.placementType === "column"
                            ? Qt.resolvedUrl("../../icons/svg/Equip_Palette/Distillation_Column.svg")
                            : Qt.resolvedUrl("../../icons/svg/Equip_Palette/Material_Stream.svg")
                    fillMode: Image.PreserveAspectFit
                    smooth: true
                    mipmap: true
                }

                // "ESC or right-click to cancel" hint label
                Label {
                    anchors.top:              parent.bottom
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.topMargin:        4
                    text:      "Click to place  •  Esc / RMB to cancel"
                    font.pixelSize: 10
                    color:     "#31404a"
                    background: Rectangle {
                        color:        "#ffffffcc"
                        radius:       3
                        border.color: "#c6d0d7"
                        border.width: 1
                    }
                    padding: 3
                }
            }

            // Escape key cancels placement mode
            // ── Right-click context menu ──────────────────────────────────
            MouseArea {
                id: contextMenuDismissArea
                anchors.fill: parent
                visible: contextMenuRect.visible
                enabled: contextMenuRect.visible
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                hoverEnabled: false
                z: 49
                onPressed: function(mouse) {
                    const insideMenu = mouse.x >= contextMenuRect.x
                                     && mouse.x <= contextMenuRect.x + contextMenuRect.width
                                     && mouse.y >= contextMenuRect.y
                                     && mouse.y <= contextMenuRect.y + contextMenuRect.height
                    if (!insideMenu) {
                        root.hideContextMenu()
                        mouse.accepted = true
                        return
                    }
                    mouse.accepted = false
                }
            }

            Rectangle {
                id: contextMenuRect
                visible: false
                z: 50
                width: 192
                height: root.contextMenuConnected ? 72 : 38
                radius: 4
                color: "#ffffff"
                border.color: "#9aaab5"
                border.width: 1

                MouseArea {
                    anchors.fill: parent
                    onPressed: function(mouse) { mouse.accepted = true }
                }

                Column {
                    anchors.fill: parent
                    anchors.margins: 2
                    spacing: 0

                    Rectangle {
                        width: parent.width
                        height: 34
                        visible: root.contextMenuConnected
                        radius: 3
                        color: disconnectHover.containsMouse ? "#ddeeff" : "transparent"
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left
                            anchors.leftMargin: 10
                            text: "Disconnect Stream"
                            font.pixelSize: 13
                            color: "#1a2a35"
                        }
                        MouseArea {
                            id: disconnectHover
                            anchors.fill: parent
                            hoverEnabled: true
                            onClicked: {
                                root.hideContextMenu()
                                if (root.flowsheet && root.contextMenuUnitId !== "") {
                                    root.flowsheet.disconnectMaterialStream(root.contextMenuUnitId)
                                    connectionOverlay.requestPaint()
                                }
                            }
                        }
                    }

                    Rectangle {
                        width: parent.width
                        height: 34
                        radius: 3
                        color: deleteHover.containsMouse ? "#ffeeee" : "transparent"
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left
                            anchors.leftMargin: 10
                            text: root.contextMenuUnitType === "column"
                                  ? "Delete Column"
                                  : (root.contextMenuUnitType === "stream" ? "Delete Stream" : "Delete Unit")
                            font.pixelSize: 13
                            color: "#8b1a1a"
                        }
                        MouseArea {
                            id: deleteHover
                            anchors.fill: parent
                            hoverEnabled: true
                            onClicked: {
                                root.hideContextMenu()
                                if (root.contextMenuUnitId !== "")
                                    root.tryDeleteUnit(root.contextMenuUnitId)
                            }
                        }
                    }
                }
            }

            Keys.onEscapePressed: root.cancelPlacement()
        }
    }
}
